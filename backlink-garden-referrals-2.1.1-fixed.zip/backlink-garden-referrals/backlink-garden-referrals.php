<?php
/**
 * Plugin Name: Backlink Garden Referral Program
 * Description: Drop-in replacement for the old Referral Tracker: partner signup, unique links, live tracker, visit + Calendly/email click tracking, form lead capture, commissions (15% first / 5% repeat) and admin. Imports old data.
 * Version: 2.1.1
 * Author: Backlink Garden
 * License: GPL-2.0-or-later
 * Text Domain: bgr
 */

if (!defined('ABSPATH')) exit;

final class BGR {

    const VER    = '2.1.1';
    const DB_VER = '3';
    const COOKIE = 'bg_ref_code';

    /* ------------------------------------------------------------------ */
    /*  Boot                                                              */
    /* ------------------------------------------------------------------ */

    static function init() {
        register_activation_hook(__FILE__, [__CLASS__, 'activate']);
        add_action('plugins_loaded', [__CLASS__, 'maybe_upgrade']);

        add_action('rest_api_init', [__CLASS__, 'register_rest']);
        add_action('wp_ajax_bgr_api', [__CLASS__, 'ajax']);
        add_action('wp_ajax_nopriv_bgr_api', [__CLASS__, 'ajax']);

        add_shortcode('bg_referral_program', [__CLASS__, 'shortcode']);
        add_shortcode('bg_referral_dashboard', [__CLASS__, 'shortcode']);
        add_shortcode('bg_partner_portal', [__CLASS__, 'shortcode']); // compatibility with old plugin's dashboard page
        add_filter('the_content', [__CLASS__, 'inject_widget'], 25);
        add_action('admin_notices', [__CLASS__, 'old_plugin_notice']);

        add_action('wp_enqueue_scripts', [__CLASS__, 'assets']);
        add_action('wp', [__CLASS__, 'dashboard_headers']);
        add_filter('wp_robots', [__CLASS__, 'robots']);

        // Form integrations (lead capture)
        add_action('wpcf7_mail_sent', [__CLASS__, 'h_cf7']);
        add_filter('wpcf7_form_hidden_fields', function ($f) { $f['referral_code'] = ''; return $f; });
        add_action('wpforms_process_complete', [__CLASS__, 'h_wpforms'], 10, 4);
        add_action('gform_after_submission', [__CLASS__, 'h_gf'], 10, 2);
        add_action('elementor_pro/forms/new_record', [__CLASS__, 'h_elementor'], 10, 2);
        add_action('fluentform/submission_inserted', [__CLASS__, 'h_fluent'], 10, 3);
        add_action('fluentform_submission_inserted', [__CLASS__, 'h_fluent'], 10, 3);
        add_action('bgr_record_lead', [__CLASS__, 'h_generic'], 10, 4); // do_action('bgr_record_lead',$name,$email,$code,$source)

        if (is_admin()) {
            add_action('admin_menu', [__CLASS__, 'admin_menu']);
            add_action('admin_post_bgr_admin', [__CLASS__, 'admin_action']);
            add_action('admin_post_bgr_export', [__CLASS__, 'admin_export']);
        }
    }

    static function t($n) { global $wpdb; return $wpdb->prefix . 'bgr_' . $n; }

    static function defaults() {
        return [
            'first_rate'         => 15,
            'repeat_rate'        => 5,
            'repeat_months'      => 12,
            'cookie_days'        => 30,
            'currency'           => '$',
            'notify_email'       => get_option('admin_email'),
            'dashboard_url'      => home_url('/backlink-referral-program/'),
            'link_base'          => home_url('/'),
            'email_partner_lead' => 1,
            'email_partner_conv' => 1,
            'delete_data'        => 0,
            'widget_pos'         => 'before_final',
        ];
    }

    static function opt($k) {
        $o = get_option('bgr_settings', []);
        $d = self::defaults();
        return (isset($o[$k]) && $o[$k] !== '') ? $o[$k] : ($d[$k] ?? '');
    }

    /* ------------------------------------------------------------------ */
    /*  Install / DB                                                      */
    /* ------------------------------------------------------------------ */

    static function activate() {
        self::install();
        $settings = get_option('bgr_settings', []);
        // Respect custom dashboard URLs and existing site pages.
        if (empty($settings['dashboard_url']) && !get_page_by_path('backlink-referral-program')) {
            $id = wp_insert_post([
                'post_title' => 'Referral Program',
                'post_name' => 'backlink-referral-program',
                'post_content' => '[bg_referral_program]',
                'post_type' => 'page',
                'post_status' => 'publish',
            ], true);
            if (!is_wp_error($id) && $id) {
                $settings['dashboard_url'] = get_permalink($id);
                update_option('bgr_settings', $settings);
            }
        }
    }

    static function maybe_upgrade() {
        if (get_option('bgr_db_ver') !== self::DB_VER) self::install();
    }

    static function install() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $c = $wpdb->get_charset_collate();

        dbDelta("CREATE TABLE " . self::t('partners') . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  name varchar(190) NOT NULL,
  email varchar(190) NOT NULL,
  code varchar(80) NOT NULL,
  token varchar(64) NOT NULL,
  status varchar(20) NOT NULL DEFAULT 'active',
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY email (email),
  UNIQUE KEY code (code),
  UNIQUE KEY token (token)
) $c;");

        dbDelta("CREATE TABLE " . self::t('visits') . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  partner_id bigint(20) unsigned NOT NULL,
  type varchar(20) NOT NULL DEFAULT 'visit',
  ip_hash char(64) NOT NULL,
  landing varchar(255) NOT NULL DEFAULT '',
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY partner_id (partner_id)
) $c;");

        dbDelta("CREATE TABLE " . self::t('referrals') . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  partner_id bigint(20) unsigned NOT NULL,
  lead_name varchar(190) NOT NULL DEFAULT '',
  lead_email varchar(190) NOT NULL,
  source varchar(60) NOT NULL DEFAULT '',
  status varchar(20) NOT NULL DEFAULT 'pending',
  notes text NULL,
  created_at datetime NOT NULL,
  converted_at datetime NULL,
  PRIMARY KEY  (id),
  KEY partner_id (partner_id),
  KEY lead_email (lead_email)
) $c;");

        dbDelta("CREATE TABLE " . self::t('orders') . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  referral_id bigint(20) unsigned NOT NULL,
  partner_id bigint(20) unsigned NOT NULL,
  amount decimal(12,2) NOT NULL DEFAULT 0,
  rate decimal(5,2) NOT NULL DEFAULT 0,
  commission decimal(12,2) NOT NULL DEFAULT 0,
  type varchar(10) NOT NULL DEFAULT 'first',
  paid tinyint(1) NOT NULL DEFAULT 0,
  order_date datetime NOT NULL,
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY referral_id (referral_id),
  KEY partner_id (partner_id)
) $c;");

        update_option('bgr_db_ver', self::DB_VER);
    }

    /* ------------------------------------------------------------------ */
    /*  Helpers                                                           */
    /* ------------------------------------------------------------------ */

    static function get_by($field, $val) {
        global $wpdb;
        if (!in_array($field, ['id', 'email', 'code', 'token'], true)) return null;
        if ($val === '' || $val === null) return null;
        $ph = $field === 'id' ? '%d' : '%s';
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM " . self::t('partners') . " WHERE $field = $ph LIMIT 1", $val));
    }

    // mbstring is optional on many WordPress hosts.
    static function text_substr($text, $start, $length) {
        if (function_exists('mb_substr')) return mb_substr($text, $start, $length, 'UTF-8');
        $chars = preg_split('//u', (string) $text, -1, PREG_SPLIT_NO_EMPTY);
        return $chars === false ? substr((string) $text, $start, $length) : implode('', array_slice($chars, $start, $length));
    }

    static function clean_code($c) {
        return substr(preg_replace('/[^A-Za-z0-9_-]/', '', (string) $c), 0, 80);
    }

    static function ip() {
        foreach (['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'] as $k) {
            if (!empty($_SERVER[$k])) {
                $v = trim(explode(',', $_SERVER[$k])[0]);
                if (filter_var($v, FILTER_VALIDATE_IP)) return $v;
            }
        }
        return '0.0.0.0';
    }

    static function ip_hash() { return hash('sha256', self::ip() . wp_salt('auth')); }

    static function limited($action, $max, $window) {
        $k = 'bgr_rl_' . md5($action . self::ip());
        $n = (int) get_transient($k);
        set_transient($k, $n + 1, $window);
        return ($n + 1) > $max;
    }

    static function money($n) { return self::opt('currency') . number_format((float) $n, 2); }

    static function ref_link($code) { return add_query_arg('ref', $code, self::opt('link_base')); }

    static function dash_link($token) { return add_query_arg('bgr_token', $token, self::opt('dashboard_url')); }

    static function mask_email($e) {
        $p = explode('@', (string) $e);
        if (count($p) !== 2) return '***';
        return self::text_substr($p[0], 0, 2) . '***@' . $p[1];
    }

    static function mask_name($n) {
        $n = trim((string) $n);
        if ($n === '') return 'Lead';
        $parts = preg_split('/\s+/', $n);
        $first = $parts[0];
        $last  = count($parts) > 1 ? ' ' . self::text_substr(end($parts), 0, 1) . '.' : '';
        return $first . $last;
    }

    static function status_label($s) {
        $m = ['pending' => 'Pending', 'converted' => 'Converted', 'rewarded' => 'Rewarded', 'rejected' => 'Rejected'];
        return $m[$s] ?? ucfirst($s);
    }

    static function mail($to, $subject, $html) {
        $body = '<div style="font-family:Arial,Helvetica,sans-serif;max-width:560px;margin:auto;padding:24px;color:#0b1f1a;line-height:1.55">'
              . $html
              . '<hr style="border:none;border-top:1px solid #e3efe9;margin:24px 0"><p style="font-size:12px;color:#6b7f78">'
              . esc_html(get_bloginfo('name')) . '</p></div>';
        ob_start(); // SMTP plugins / PHP notices must never corrupt the JSON response
        $sent = wp_mail($to, $subject, $body, ['Content-Type: text/html; charset=UTF-8']);
        ob_end_clean();
        return $sent;
    }

    static function make_code($name) {
        global $wpdb;
        $base = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', remove_accents($name)));
        $base = substr($base, 0, 6);
        if (strlen($base) < 3) $base = 'BG' . $base;
        for ($i = 0; $i < 25; $i++) {
            $code = $base . wp_rand(100, 9999);
            if (!$wpdb->get_var($wpdb->prepare("SELECT id FROM " . self::t('partners') . " WHERE code = %s", $code))) return $code;
        }
        return strtoupper(wp_generate_password(10, false));
    }

    static function create_partner($name, $email) {
        global $wpdb;
        $ok = $wpdb->insert(self::t('partners'), [
            'name'       => $name,
            'email'      => $email,
            'code'       => self::make_code($name),
            'token'      => bin2hex(random_bytes(24)),
            'status'     => 'active',
            'created_at' => current_time('mysql'),
        ]);
        return $ok ? self::get_by('id', $wpdb->insert_id) : null;
    }

    /* ------------------------------------------------------------------ */
    /*  API core (shared by REST + admin-ajax)                            */
    /* ------------------------------------------------------------------ */

    static function register_rest() {
        foreach (['signup', 'resend', 'visit', 'lead', 'stats'] as $route) {
            register_rest_route('bgr/v1', '/' . $route, [
                'methods'             => 'POST',
                'permission_callback' => '__return_true',
                'callback'            => function ($req) use ($route) {
                    $p = $req->get_json_params();
                    if (!is_array($p)) $p = $req->get_params();
                    list($status, $data) = self::handle($route, $p);
                    return new WP_REST_Response($data, $status);
                },
            ]);
        }
    }

    static function ajax() {
        $route = sanitize_key($_POST['route'] ?? '');
        $p = wp_unslash($_POST);
        list($status, $data) = self::handle($route, $p);
        wp_send_json($data, $status);
    }

    static function handle($route, $p) {
        switch ($route) {
            case 'signup': return self::do_signup($p);
            case 'resend': return self::do_resend($p);
            case 'visit':  return self::do_visit($p);
            case 'lead':   return self::do_lead($p);
            case 'stats':  return self::do_stats($p);
        }
        return [404, ['ok' => false, 'message' => 'Unknown route.']];
    }

    static function err($msg, $status = 400) { return [$status, ['ok' => false, 'message' => $msg]]; }

    static function do_signup($p) {
        if (!empty($p['bgr_confirm'])) return [200, ['ok' => true, 'existing' => true, 'message' => 'Done.']]; // honeypot
        if (self::limited('signup', 6, HOUR_IN_SECONDS)) return self::err('Too many attempts. Please try again in a while.', 429);

        $name  = sanitize_text_field($p['name'] ?? '');
        $email = sanitize_email($p['email'] ?? '');
        if (count(preg_split('//u', $name, -1, PREG_SPLIT_NO_EMPTY) ?: str_split($name)) < 2)  return self::err('Please enter your name.');
        if (!is_email($email))     return self::err('Please enter a valid email address.');

        $partner = self::get_by('email', $email);
        if ($partner) {
            if (!self::send_dashboard_email($partner, false)) return self::err('Your account exists, but email delivery failed. Please contact the site administrator.', 503);
            return [200, ['ok' => true, 'existing' => true, 'message' => 'You already have an account. We just emailed your dashboard link.']];
        }

        $partner = self::create_partner($name, $email);
        if (!$partner) return self::err('Could not create your account. Please try again.', 500);

        $email_sent = self::send_dashboard_email($partner, true);

        $to = self::opt('notify_email');
        if ($to) {
            self::mail($to, 'New referral partner: ' . $partner->name,
                '<p><strong>' . esc_html($partner->name) . '</strong> (' . esc_html($partner->email) . ') joined the referral program.</p><p>Code: <strong>' . esc_html($partner->code) . '</strong></p>');
        }

        return [200, ['ok' => true, 'existing' => false, 'name' => $partner->name, 'code' => $partner->code,
            'link' => self::ref_link($partner->code), 'dashboard' => self::dash_link($partner->token), 'email_sent' => (bool) $email_sent]];
    }

    static function do_resend($p) {
        if (self::limited('resend', 5, HOUR_IN_SECONDS)) return self::err('Too many attempts. Please try again in a while.', 429);
        $email = sanitize_email($p['email'] ?? '');
        if (!is_email($email)) return self::err('Please enter a valid email address.');
        $partner = self::get_by('email', $email);
        if ($partner && !self::send_dashboard_email($partner, false)) return self::err('Email delivery is unavailable. Please contact the site administrator.', 503);
        // Same response either way (no account enumeration)
        return [200, ['ok' => true, 'message' => 'If that email belongs to a partner, a dashboard link is on its way. Please check your inbox (and spam).']];
    }

    static function do_visit($p) {
        global $wpdb;
        $code = self::clean_code($p['code'] ?? '');
        $type = sanitize_key($p['type'] ?? 'visit');
        if (!in_array($type, ['visit', 'calendly', 'email'], true)) $type = 'visit';
        $partner = self::get_by('code', $code);
        if (!$partner || $partner->status !== 'active') return [200, ['ok' => true, 'valid' => false]];

        $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
        if (!$ua || preg_match('/bot|crawl|spider|slurp|preview|headless|monitor/i', $ua)) return [200, ['ok' => true, 'valid' => true]];

        $ih  = self::ip_hash();
        $key = 'bgr_v_' . md5($ih . $partner->id . $type);
        if (!get_transient($key)) {
            set_transient($key, 1, $type === 'visit' ? DAY_IN_SECONDS : 60);
            $wpdb->insert(self::t('visits'), [
                'partner_id' => $partner->id,
                'type'       => $type,
                'ip_hash'    => $ih,
                'landing'    => substr(sanitize_text_field($p['landing'] ?? ''), 0, 250),
                'created_at' => current_time('mysql'),
            ]);
        }
        return [200, ['ok' => true, 'valid' => true]];
    }

    static function do_lead($p) {
        if (self::limited('lead', 20, HOUR_IN_SECONDS)) return self::err('Too many requests.', 429);
        $id = self::record_lead(sanitize_text_field($p['name'] ?? ''), $p['email'] ?? '', $p['code'] ?? '', 'api');
        return [200, ['ok' => true, 'recorded' => (bool) $id]];
    }

    static function do_stats($p) {
        $token = preg_replace('/[^a-f0-9]/', '', strtolower((string) ($p['token'] ?? '')));
        $partner = self::get_by('token', $token);
        if (!$partner) return self::err('Invalid dashboard link.', 403);
        return [200, ['ok' => true] + self::payload($partner)];
    }

    /* ------------------------------------------------------------------ */
    /*  Stats payload                                                     */
    /* ------------------------------------------------------------------ */

    static function payload($partner) {
        global $wpdb;
        $id = (int) $partner->id;
        $tv = self::t('visits'); $tr = self::t('referrals'); $to = self::t('orders');

        $visits    = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $tv WHERE partner_id = %d AND type = 'visit'", $id));
        $calendly  = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $tv WHERE partner_id = %d AND type = 'calendly'", $id));
        $emails    = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $tv WHERE partner_id = %d AND type = 'email'", $id));
        $leads     = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $tr WHERE partner_id = %d", $id));
        $converted = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $tr WHERE partner_id = %d AND status IN ('converted','rewarded')", $id));
        $earned    = (float) $wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(commission),0) FROM $to WHERE partner_id = %d", $id));
        $unpaid    = (float) $wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(commission),0) FROM $to WHERE partner_id = %d AND paid = 0", $id));

        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT r.id, r.lead_name, r.lead_email, r.status, r.created_at,
                    (SELECT COALESCE(SUM(o.commission),0) FROM $to o WHERE o.referral_id = r.id) AS commission
             FROM $tr r WHERE r.partner_id = %d ORDER BY r.id DESC LIMIT 100", $id));

        $list = [];
        foreach ($rows as $r) {
            $list[] = [
                'date'       => mysql2date('M j, Y', $r->created_at),
                'lead'       => self::mask_name($r->lead_name) . ' · ' . self::mask_email($r->lead_email),
                'status'     => $r->status,
                'label'      => self::status_label($r->status),
                'commission' => (float) $r->commission > 0 ? self::money($r->commission) : '—',
            ];
        }

        return [
            'stats' => [
                'visits'    => $visits,
                'calendly'  => $calendly,
                'email'     => $emails,
                'leads'     => $leads,
                'converted' => $converted,
                'unpaid'    => self::money($unpaid),
                'earned'    => self::money($earned),
            ],
            'rows' => $list,
        ];
    }

    /* ------------------------------------------------------------------ */
    /*  Emails                                                            */
    /* ------------------------------------------------------------------ */

    static function send_dashboard_email($partner, $welcome) {
        $link = self::ref_link($partner->code);
        $dash = self::dash_link($partner->token);
        $first = explode(' ', trim($partner->name))[0];

        $html  = '<h2 style="margin:0 0 12px">' . ($welcome ? 'Welcome to the referral program!' : 'Your dashboard link') . '</h2>';
        $html .= '<p>Hi ' . esc_html($first) . ',</p>';
        if ($welcome) {
            $html .= '<p>You earn <strong>' . (float) self::opt('first_rate') . '%</strong> on the first qualifying paid order and <strong>' . (float) self::opt('repeat_rate')
                  . '%</strong> on qualifying repeat orders for up to ' . (int) self::opt('repeat_months') . ' months.</p>';
        }
        $html .= '<p><strong>Your referral link</strong><br><a href="' . esc_url($link) . '">' . esc_html($link) . '</a></p>';
        $html .= '<p><strong>Your referral code:</strong> ' . esc_html($partner->code) . '</p>';
        $html .= '<p><a href="' . esc_url($dash) . '" style="display:inline-block;background:#00d68f;color:#062b20;text-decoration:none;font-weight:bold;padding:12px 22px;border-radius:10px">Open my dashboard</a></p>';
        $html .= '<p style="font-size:13px;color:#6b7f78">Keep this email safe. The dashboard link is private to you.</p>';

        return self::mail($partner->email, $welcome ? 'Your referral link & dashboard' : 'Your referral dashboard link', $html);
    }

    /* ------------------------------------------------------------------ */
    /*  Leads + commissions                                               */
    /* ------------------------------------------------------------------ */

    static function record_lead($name, $email, $code = '', $source = 'form') {
        global $wpdb;
        $email = sanitize_email($email);
        if (!is_email($email)) return false;

        if (!$code && !empty($_COOKIE[self::COOKIE])) $code = $_COOKIE[self::COOKIE];
        $code = self::clean_code($code);
        if (!$code) return false;

        $partner = self::get_by('code', $code);
        if (!$partner || $partner->status !== 'active') return false;
        if (strtolower($partner->email) === strtolower($email)) return false; // no self-referrals

        $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM " . self::t('referrals') . " WHERE lead_email = %s LIMIT 1", $email));
        if ($exists) return false;

        $ok = $wpdb->insert(self::t('referrals'), [
            'partner_id' => $partner->id,
            'lead_name'  => self::text_substr(sanitize_text_field($name), 0, 190),
            'lead_email' => $email,
            'source'     => self::text_substr(sanitize_text_field($source), 0, 60),
            'status'     => 'pending',
            'created_at' => current_time('mysql'),
        ]);
        if (!$ok) return false;
        $rid = (int) $wpdb->insert_id;

        $to = self::opt('notify_email');
        if ($to) {
            self::mail($to, 'New referral lead via ' . $partner->name,
                '<p>New lead from partner <strong>' . esc_html($partner->name) . '</strong> (code ' . esc_html($partner->code) . ').</p>'
                . '<p>Lead: ' . esc_html($name) . ' &lt;' . esc_html($email) . '&gt;<br>Source: ' . esc_html($source) . '</p>');
        }
        if (self::opt('email_partner_lead')) {
            self::mail($partner->email, 'You have a new referral!',
                '<p>Good news, ' . esc_html(explode(' ', $partner->name)[0]) . '! <strong>' . esc_html(self::mask_name($name)) . '</strong> ('
                . esc_html(self::mask_email($email)) . ') just came in through your referral link.</p>'
                . '<p><a href="' . esc_url(self::dash_link($partner->token)) . '">Track it on your dashboard</a></p>');
        }
        return $rid;
    }

    static function add_order($rid, $amount, $date = '', $force = '') {
        global $wpdb;
        $ref = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . self::t('referrals') . " WHERE id = %d", $rid));
        if (!$ref) return false;
        $amount = max(0, (float) $amount);

        $ts = $date ? strtotime($date) : time();
        if (!$ts) $ts = time();

        $first = $wpdb->get_var($wpdb->prepare("SELECT MIN(order_date) FROM " . self::t('orders') . " WHERE referral_id = %d", $rid));
        if ($force === 'first')       { $type = 'first';  $rate = (float) self::opt('first_rate'); }
        elseif ($force === 'repeat')  { $type = 'repeat'; $rate = (float) self::opt('repeat_rate'); }
        elseif (!$first) {
            $type = 'first';  $rate = (float) self::opt('first_rate');
        } else {
            $limit = strtotime('+' . (int) self::opt('repeat_months') . ' months', strtotime($first));
            if ($ts <= $limit) { $type = 'repeat';  $rate = (float) self::opt('repeat_rate'); }
            else               { $type = 'expired'; $rate = 0.0; }
        }
        $commission = round($amount * $rate / 100, 2);

        $saved = $wpdb->insert(self::t('orders'), [
            'referral_id' => $rid,
            'partner_id'  => $ref->partner_id,
            'amount'      => $amount,
            'rate'        => $rate,
            'commission'  => $commission,
            'type'        => $type,
            'paid'        => 0,
            'order_date'  => gmdate('Y-m-d H:i:s', $ts),
            'created_at'  => current_time('mysql'),
        ]);

        if (!$saved) return false;

        $was = $ref->status;
        $wpdb->update(self::t('referrals'), [
            'status'       => 'converted',
            'converted_at' => $ref->converted_at ?: current_time('mysql'),
        ], ['id' => $rid]);

        if ($commission > 0 && $was === 'pending' && self::opt('email_partner_conv')) {
            $partner = self::get_by('id', $ref->partner_id);
            if ($partner) {
                self::mail($partner->email, 'Your referral converted!',
                    '<p>Great news! <strong>' . esc_html(self::mask_name($ref->lead_name)) . '</strong> became a paying client. You earned <strong>'
                    . esc_html(self::money($commission)) . '</strong>.</p><p><a href="' . esc_url(self::dash_link($partner->token)) . '">View your dashboard</a></p>');
            }
        }
        return true;
    }

    static function sync_referral_status($rid) {
        global $wpdb;
        $ref = $wpdb->get_row($wpdb->prepare("SELECT status FROM " . self::t('referrals') . " WHERE id = %d", $rid));
        if (!$ref || !in_array($ref->status, ['converted', 'rewarded'], true)) return;
        $tot    = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM " . self::t('orders') . " WHERE referral_id = %d", $rid));
        $unpaid = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM " . self::t('orders') . " WHERE referral_id = %d AND paid = 0", $rid));
        if (!$tot) {
            $wpdb->update(self::t('referrals'), ['status' => 'pending', 'converted_at' => null], ['id' => $rid]);
            return;
        }
        if ($tot > 0) $wpdb->update(self::t('referrals'), ['status' => $unpaid ? 'converted' : 'rewarded'], ['id' => $rid]);
    }

    /* ------------------------------------------------------------------ */
    /*  Form integrations                                                 */
    /* ------------------------------------------------------------------ */

    static function extract_contact($data) {
        $name = ''; $email = '';
        foreach ((array) $data as $k => $v) {
            if (is_array($v)) $v = implode(' ', array_filter($v, 'is_scalar'));
            $v = trim((string) $v);
            $k = strtolower((string) $k);
            if (!$email && is_email($v)) { $email = $v; continue; }
            if (!$name && strpos($k, 'name') !== false && !preg_match('/user|company|business|site|domain|url/', $k)) $name = $v;
        }
        return [$name, $email];
    }

    static function posted_code() {
        return isset($_POST['referral_code']) ? self::clean_code(wp_unslash($_POST['referral_code'])) : '';
    }

    static function h_cf7($form) {
        if (!class_exists('WPCF7_Submission')) return;
        $s = WPCF7_Submission::get_instance();
        if (!$s) return;
        $d = $s->get_posted_data();
        list($n, $e) = self::extract_contact($d);
        $code = !empty($d['referral_code']) ? $d['referral_code'] : self::posted_code();
        self::record_lead($n, $e, is_array($code) ? '' : $code, 'Contact Form 7');
    }

    static function h_wpforms($fields, $entry, $form_data, $entry_id) {
        $name = ''; $email = ''; $code = '';
        foreach ((array) $fields as $f) {
            $type = $f['type'] ?? ''; $val = $f['value'] ?? '';
            if ($type === 'email' && !$email) $email = is_array($val) ? ($val['primary'] ?? '') : $val;
            elseif ($type === 'name' && !$name) $name = $val;
            elseif (stripos($f['name'] ?? '', 'referral') !== false) $code = $val;
        }
        if (!$email) list($name, $email) = self::extract_contact(wp_list_pluck((array) $fields, 'value', 'name'));
        self::record_lead($name, $email, $code ?: self::posted_code(), 'WPForms');
    }

    static function h_gf($entry, $form) {
        $name = ''; $email = ''; $code = '';
        foreach ((array) ($form['fields'] ?? []) as $f) {
            if ($f->type === 'email' && !$email) $email = rgar($entry, (string) $f->id);
            elseif ($f->type === 'name' && !$name) $name = trim(rgar($entry, $f->id . '.3') . ' ' . rgar($entry, $f->id . '.6'));
            elseif (stripos((string) $f->label, 'referral') !== false) $code = rgar($entry, (string) $f->id);
        }
        self::record_lead($name, $email, $code ?: self::posted_code(), 'Gravity Forms');
    }

    static function h_elementor($record, $handler) {
        $flat = [];
        foreach ((array) $record->get('fields') as $id => $f) $flat[$id] = $f['value'] ?? '';
        list($n, $e) = self::extract_contact($flat);
        $code = '';
        foreach ($flat as $id => $v) if (stripos((string) $id, 'referral') !== false) $code = $v;
        self::record_lead($n, $e, $code, 'Elementor Form');
    }

    static function h_fluent($insertId, $formData, $form) {
        list($n, $e) = self::extract_contact((array) $formData);
        $code = $formData['referral_code'] ?? '';
        self::record_lead($n, $e, is_array($code) ? '' : $code, 'Fluent Forms');
    }

    static function h_generic($name = '', $email = '', $code = '', $source = 'custom') {
        self::record_lead($name, $email, $code, $source);
    }

    /* ------------------------------------------------------------------ */
    /*  Front end                                                         */
    /* ------------------------------------------------------------------ */

    static function assets() {
        wp_enqueue_style('bgr', plugins_url('assets/bgr.css', __FILE__), [], self::VER);
        wp_enqueue_script('bgr', plugins_url('assets/bgr.js', __FILE__), [], self::VER, true);
        wp_localize_script('bgr', 'BGR', [
            'rest'   => esc_url_raw(rest_url('bgr/v1/')),
            'ajax'   => admin_url('admin-ajax.php'),
            'cookie' => self::COOKIE,
            'days'   => (int) self::opt('cookie_days'),
            'dash'   => esc_url_raw(self::opt('dashboard_url')),
        ]);
    }

    static function req_token() {
        $raw = $_GET['bgr_token'] ?? ($_GET['key'] ?? '');
        return preg_replace('/[^a-f0-9]/', '', strtolower((string) $raw));
    }

    static function has_token() {
        if (!empty($_GET['bgr_token'])) return true;
        if (!empty($_GET['key']) && is_singular()) {
            $p = get_queried_object();
            if ($p && !empty($p->post_content) && (has_shortcode($p->post_content, 'bg_partner_portal') || has_shortcode($p->post_content, 'bg_referral_program') || has_shortcode($p->post_content, 'bg_referral_dashboard'))) return true;
        }
        return false;
    }

    static function dashboard_headers() {
        if (!self::has_token()) return;
        if (!defined('DONOTCACHEPAGE')) define('DONOTCACHEPAGE', true);
        nocache_headers();
        if (!headers_sent()) header('Referrer-Policy: no-referrer');
    }

    static function robots($r) {
        if (self::has_token()) { $r['noindex'] = true; $r['nofollow'] = true; unset($r['max-image-preview']); }
        return $r;
    }

    static function terms_text() {
        return sprintf('Free to join. You earn %s%% on the first qualifying paid order and %s%% on qualifying repeat orders for up to %d months.',
            (float) self::opt('first_rate'), (float) self::opt('repeat_rate'), (int) self::opt('repeat_months'));
    }

    static function shortcode($atts = []) {
        $atts = shortcode_atts(['heading' => 'no'], (array) $atts);
        return self::render_app($atts['heading'] === 'yes');
    }

    static function render_app($heading = false) {
        $token = self::req_token();
        $invalid = false;
        if ($token) {
            $partner = self::get_by('token', $token);
            if ($partner && $partner->status === 'active') return self::render_dashboard($partner);
            $invalid = true;
        }
        return self::render_signup($invalid, $heading);
    }

    static function inject_widget($content) {
        static $done = false;
        if ($done || is_admin() || is_feed() || doing_filter('get_the_excerpt')) return $content;
        if (!is_singular() || !in_the_loop() || !is_main_query()) return $content;
        if (function_exists('bgref_widget_html')) return $content; // old plugin still active
        $pos = self::opt('widget_pos');
        if ($pos === 'off' || strpos($content, 'rfp-page') === false) return $content;
        if (has_shortcode($content, 'bg_referral_program') || has_shortcode($content, 'bg_partner_portal') || has_shortcode($content, 'bg_referral_dashboard') || strpos($content, 'data-bgr-app') !== false || strpos($content, 'data-bgr-dash') !== false) return $content;
        $done = true;
        $w = self::render_app(true);

        if ($pos === 'after_hero') {
            $i = strpos($content, '</header>');
            if ($i !== false) { $i += 9; return substr($content, 0, $i) . $w . substr($content, $i); }
        } elseif ($pos === 'before_final') {
            $i = strpos($content, '<section class="rfp-final"');
            if ($i !== false) return substr($content, 0, $i) . $w . substr($content, $i);
        }
        return $content . $w;
    }

    static function old_plugin_notice() {
        if (!function_exists('bgref_widget_html') || !current_user_can('manage_options')) return;
        echo '<div class="notice notice-warning"><p><strong>Backlink Garden Referral Program:</strong> the old plugin "Backlink Garden Referral Tracker" is still active. Go to Referrals &rarr; Settings &rarr; <em>Import from old plugin</em>, then <strong>deactivate the old plugin</strong> to avoid double tracking and two signup forms.</p></div>';
    }

    static function render_signup($invalid = false, $heading = false) {
        ob_start(); ?>
<div class="bgr-wrap" data-bgr-app>
  <?php if ($heading) : ?>
  <div class="bgr-head">
    <h2>Get Your Referral Link &amp; Track Your Referrals</h2>
    <p>Join free in seconds. You get your own unique code and link to share, plus a live tracker that shows visits, referrals and whether they converted.</p>
  </div>
  <?php endif; ?>
  <div class="bgr-card">
    <div class="bgr-msg bgr-error" role="alert" <?php echo $invalid ? '' : 'hidden'; ?>><?php echo $invalid ? esc_html('That dashboard link is invalid or has been disabled. Use the form below to get a new link by email.') : ''; ?></div>

    <div class="bgr-panel" data-panel="signup">
      <form class="bgr-form" data-bgr="signup" novalidate>
        <div class="bgr-row">
          <div class="bgr-field"><label for="bgr-name">Your name</label><input id="bgr-name" type="text" name="name" autocomplete="name" required></div>
          <div class="bgr-field"><label for="bgr-email">Your email</label><input id="bgr-email" type="email" name="email" autocomplete="email" required></div>
        </div>
        <input type="text" name="bgr_confirm" class="bgr-hp" tabindex="-1" autocomplete="off" aria-hidden="true">
        <button type="submit" class="bgr-btn">Get my referral link</button>
      </form>
      <p class="bgr-terms"><?php echo esc_html(self::terms_text()); ?></p>
      <p class="bgr-alt"><a href="#" data-toggle="resend">Already a partner? Email me my dashboard link</a></p>
    </div>

    <div class="bgr-panel" data-panel="resend" hidden>
      <form class="bgr-form" data-bgr="resend" novalidate>
        <div class="bgr-field"><label for="bgr-email2">Your email</label><input id="bgr-email2" type="email" name="email" autocomplete="email" required></div>
        <button type="submit" class="bgr-btn">Email me my dashboard link</button>
      </form>
      <p class="bgr-alt"><a href="#" data-toggle="signup">&larr; Back to sign up</a></p>
    </div>

    <div class="bgr-panel bgr-success" data-panel="success" hidden></div>
  </div>
</div>
<?php
        return ob_get_clean();
    }

    static function render_dashboard($partner) {
        $data  = self::payload($partner);
        $link  = self::ref_link($partner->code);
        $first = explode(' ', trim($partner->name))[0];
        $share = rawurlencode($link);
        $text  = rawurlencode('Check out Backlink Garden: ' . $link);

        $cards = [
            'visits'    => 'Link visits',
            'calendly'  => 'Call-booking clicks',
            'email'     => 'Email clicks',
            'leads'     => 'Referrals',
            'converted' => 'Converted',
            'unpaid'    => 'Pending payout',
            'earned'    => 'Total earned',
        ];

        ob_start(); ?>
<div class="bgr-wrap bgr-dash" data-bgr-dash data-token="<?php echo esc_attr($partner->token); ?>">
  <div class="bgr-card">
    <h3 class="bgr-h">Welcome back, <?php echo esc_html($first); ?> 👋</h3>
    <p class="bgr-sub">Your code: <strong><?php echo esc_html($partner->code); ?></strong></p>

    <label class="bgr-lbl" for="bgr-mylink">Your referral link</label>
    <div class="bgr-copy">
      <input id="bgr-mylink" type="text" readonly value="<?php echo esc_attr($link); ?>">
      <button type="button" class="bgr-btn" data-copy="<?php echo esc_attr($link); ?>">Copy</button>
    </div>
    <p class="bgr-share">
      <a target="_blank" rel="noopener" href="https://wa.me/?text=<?php echo $text; ?>">WhatsApp</a> ·
      <a target="_blank" rel="noopener" href="https://www.linkedin.com/sharing/share-offsite/?url=<?php echo $share; ?>">LinkedIn</a> ·
      <a target="_blank" rel="noopener" href="https://twitter.com/intent/tweet?url=<?php echo $share; ?>">X</a>
    </p>

    <div class="bgr-stats">
      <?php foreach ($cards as $k => $label) : ?>
        <div class="bgr-stat"><span class="bgr-num" data-stat="<?php echo esc_attr($k); ?>"><?php echo esc_html($data['stats'][$k]); ?></span><span class="bgr-cap"><?php echo esc_html($label); ?></span></div>
      <?php endforeach; ?>
    </div>

    <h4 class="bgr-h2">Your referrals <small class="bgr-live">● live</small></h4>
    <div class="bgr-tablewrap">
      <table class="bgr-table">
        <thead><tr><th>Date</th><th>Lead</th><th>Status</th><th>Commission</th></tr></thead>
        <tbody data-rows>
          <?php if (!$data['rows']) : ?>
            <tr class="bgr-empty"><td colspan="4">No referrals yet. Share your link to get started.</td></tr>
          <?php else : foreach ($data['rows'] as $r) : ?>
            <tr><td><?php echo esc_html($r['date']); ?></td><td><?php echo esc_html($r['lead']); ?></td>
                <td><span class="bgr-badge bgr-<?php echo esc_attr($r['status']); ?>"><?php echo esc_html($r['label']); ?></span></td>
                <td><?php echo esc_html($r['commission']); ?></td></tr>
          <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
    <p class="bgr-terms"><?php echo esc_html(self::terms_text()); ?> Commission is confirmed once a paid order is verified.</p>
  </div>
</div>
<?php
        return ob_get_clean();
    }

    /* ------------------------------------------------------------------ */
    /*  Admin                                                             */
    /* ------------------------------------------------------------------ */

    static function admin_menu() {
        add_menu_page('Referrals', 'Referrals', 'manage_options', 'bgr', [__CLASS__, 'admin_page'], 'dashicons-share', 58);
    }

    static function fo($do, $hidden = []) {
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="display:inline-block;margin:0 4px 0 0">';
        echo '<input type="hidden" name="action" value="bgr_admin"><input type="hidden" name="do" value="' . esc_attr($do) . '">';
        foreach ($hidden as $k => $v) echo '<input type="hidden" name="' . esc_attr($k) . '" value="' . esc_attr($v) . '">';
        wp_nonce_field('bgr_admin');
    }

    static function partner_rows($limit = 500) {
        global $wpdb;
        $p = self::t('partners'); $v = self::t('visits'); $r = self::t('referrals'); $o = self::t('orders');
        return $wpdb->get_results($wpdb->prepare(
            "SELECT p.*,
              (SELECT COUNT(*) FROM $v x WHERE x.partner_id = p.id AND x.type = 'visit') AS visits,
              (SELECT COUNT(*) FROM $v x WHERE x.partner_id = p.id AND x.type IN ('calendly','email')) AS clicks,
              (SELECT COUNT(*) FROM $r x WHERE x.partner_id = p.id) AS leads,
              (SELECT COUNT(*) FROM $r x WHERE x.partner_id = p.id AND x.status IN ('converted','rewarded')) AS converted,
              (SELECT COALESCE(SUM(commission),0) FROM $o x WHERE x.partner_id = p.id) AS earned,
              (SELECT COALESCE(SUM(commission),0) FROM $o x WHERE x.partner_id = p.id AND x.paid = 0) AS unpaid
             FROM $p p ORDER BY p.id DESC LIMIT %d", $limit));
    }

    static function admin_page() {
        if (!current_user_can('manage_options')) return;
        $tab  = sanitize_key($_GET['tab'] ?? 'overview');
        $tabs = ['overview' => 'Overview', 'partners' => 'Partners', 'referrals' => 'Referrals', 'orders' => 'Orders & Payouts', 'settings' => 'Settings'];
        if (!isset($tabs[$tab])) $tab = 'overview';

        echo '<div class="wrap"><h1>Referral Program</h1>';
        if (!empty($_GET['bgr_msg'])) echo '<div class="notice notice-success is-dismissible"><p>' . esc_html(wp_unslash($_GET['bgr_msg'])) . '</p></div>';
        echo '<h2 class="nav-tab-wrapper">';
        foreach ($tabs as $k => $l) {
            echo '<a class="nav-tab' . ($k === $tab ? ' nav-tab-active' : '') . '" href="' . esc_url(admin_url('admin.php?page=bgr&tab=' . $k)) . '">' . esc_html($l) . '</a>';
        }
        echo '</h2><div style="margin-top:16px">';
        call_user_func([__CLASS__, 'tab_' . $tab]);
        echo '</div></div>';
    }

    static function tab_overview() {
        global $wpdb;
        $tp = self::t('partners');
        $n = [
            'Partners'       => (int) $wpdb->get_var("SELECT COUNT(*) FROM $tp"),
            'Visits'         => (int) $wpdb->get_var("SELECT COUNT(*) FROM " . self::t('visits') . " WHERE type = 'visit'"),
            'Booking/email clicks' => (int) $wpdb->get_var("SELECT COUNT(*) FROM " . self::t('visits') . " WHERE type <> 'visit'"),
            'Referrals'      => (int) $wpdb->get_var("SELECT COUNT(*) FROM " . self::t('referrals')),
            'Converted'      => (int) $wpdb->get_var("SELECT COUNT(*) FROM " . self::t('referrals') . " WHERE status IN ('converted','rewarded')"),
            'Owed (unpaid)'  => self::money($wpdb->get_var("SELECT COALESCE(SUM(commission),0) FROM " . self::t('orders') . " WHERE paid = 0")),
            'Paid out'       => self::money($wpdb->get_var("SELECT COALESCE(SUM(commission),0) FROM " . self::t('orders') . " WHERE paid = 1")),
        ];
        echo '<div style="display:flex;gap:12px;flex-wrap:wrap">';
        foreach ($n as $l => $v) echo '<div style="background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:14px 20px;min-width:130px"><div style="font-size:24px;font-weight:600">' . esc_html($v) . '</div><div style="color:#646970">' . esc_html($l) . '</div></div>';
        echo '</div>';

        $rows = self::partner_rows(10);
        echo '<h3 style="margin-top:24px">Latest partners</h3>';
        self::partners_table($rows, false);

        echo '<p style="margin-top:24px"><a class="button" href="' . esc_url(wp_nonce_url(admin_url('admin-post.php?action=bgr_export'), 'bgr_export')) . '">Export referrals (CSV)</a></p>';
    }

    static function partners_table($rows, $actions = true) {
        echo '<table class="widefat striped"><thead><tr><th>Partner</th><th>Code</th><th>Visits</th><th>Clicks</th><th>Leads</th><th>Converted</th><th>Earned</th><th>Unpaid</th><th>Status</th><th>Joined</th>' . ($actions ? '<th>Actions</th>' : '') . '</tr></thead><tbody>';
        if (!$rows) echo '<tr><td colspan="11">No partners yet.</td></tr>';
        foreach ($rows as $p) {
            echo '<tr><td><strong>' . esc_html($p->name) . '</strong><br>' . esc_html($p->email) . '</td>';
            echo '<td><code>' . esc_html($p->code) . '</code></td><td>' . (int) $p->visits . '</td><td>' . (int) $p->clicks . '</td><td>' . (int) $p->leads . '</td><td>' . (int) $p->converted . '</td>';
            echo '<td>' . esc_html(self::money($p->earned)) . '</td><td>' . esc_html(self::money($p->unpaid)) . '</td>';
            echo '<td>' . esc_html(ucfirst($p->status)) . '</td><td>' . esc_html(mysql2date('Y-m-d', $p->created_at)) . '</td>';
            if ($actions) {
                echo '<td><a class="button button-small" target="_blank" href="' . esc_url(self::dash_link($p->token)) . '">Dashboard</a> ';
                self::fo('toggle_partner', ['id' => $p->id]); echo '<button class="button button-small">' . ($p->status === 'active' ? 'Disable' : 'Enable') . '</button></form>';
                self::fo('resend_partner', ['id' => $p->id]); echo '<button class="button button-small">Email link</button></form>';
                self::fo('delete_partner', ['id' => $p->id]); echo '<button class="button button-small" onclick="return confirm(\'Delete this partner and all their data?\')">Delete</button></form></td>';
            }
            echo '</tr>';
        }
        echo '</tbody></table>';
    }

    static function tab_partners() {
        echo '<h3>Add partner manually</h3>';
        self::fo('add_partner');
        echo '<input type="text" name="name" placeholder="Name" required> <input type="email" name="email" placeholder="Email" required> <button class="button button-primary">Add partner</button></form>';
        echo '<h3 style="margin-top:24px">All partners</h3>';
        self::partners_table(self::partner_rows(500), true);
    }

    static function tab_referrals() {
        global $wpdb;
        $rows = $wpdb->get_results(
            "SELECT r.*, p.name AS pname, p.code AS pcode,
                    (SELECT COUNT(*) FROM " . self::t('orders') . " o WHERE o.referral_id = r.id) AS n_orders,
                    (SELECT COALESCE(SUM(o.commission),0) FROM " . self::t('orders') . " o WHERE o.referral_id = r.id) AS commission
             FROM " . self::t('referrals') . " r LEFT JOIN " . self::t('partners') . " p ON p.id = r.partner_id
             ORDER BY r.id DESC LIMIT 500");
        $partners = $wpdb->get_results("SELECT id, name, code FROM " . self::t('partners') . " ORDER BY name ASC");
        echo '<h3>Log a lead manually <small style="font-weight:normal">(e.g. someone who booked via Calendly or emailed you)</small></h3>';
        self::fo('add_lead');
        echo '<select name="partner_id" required><option value="">Partner…</option>';
        foreach ($partners as $pp) echo '<option value="' . (int) $pp->id . '">' . esc_html($pp->name . ' (' . $pp->code . ')') . '</option>';
        echo '</select> <input type="text" name="name" placeholder="Client / company" required> <input type="email" name="email" placeholder="Email (optional)"> <button class="button button-primary">Add lead</button></form>';
        echo '<p style="margin-top:14px"><a class="button" href="' . esc_url(wp_nonce_url(admin_url('admin-post.php?action=bgr_export'), 'bgr_export')) . '">Export CSV</a></p>';
        echo '<p class="description">Set a lead to <strong>Converted</strong> only when they become a paying client. Adding an order calculates the commission automatically (first order ' . (float) self::opt('first_rate') . '%, repeats ' . (float) self::opt('repeat_rate') . '% for ' . (int) self::opt('repeat_months') . ' months).</p>';
        echo '<table class="widefat striped"><thead><tr><th>Date</th><th>Partner</th><th>Lead</th><th>Source</th><th>Status</th><th>Orders / Commission</th><th>Add paid order</th><th></th></tr></thead><tbody>';
        if (!$rows) echo '<tr><td colspan="8">No referrals yet.</td></tr>';
        foreach ($rows as $r) {
            echo '<tr><td>' . esc_html(mysql2date('Y-m-d', $r->created_at)) . '</td>';
            echo '<td>' . esc_html($r->pname) . '<br><code>' . esc_html($r->pcode) . '</code></td>';
            echo '<td>' . esc_html($r->lead_name) . '<br>' . esc_html($r->lead_email) . '</td><td>' . esc_html($r->source) . '</td><td>';
            self::fo('set_status', ['id' => $r->id]);
            echo '<select name="status">';
            foreach (['pending', 'converted', 'rewarded', 'rejected'] as $s) echo '<option value="' . $s . '"' . selected($r->status, $s, false) . '>' . esc_html(self::status_label($s)) . '</option>';
            echo '</select> <button class="button button-small">Save</button></form></td>';
            echo '<td>' . (int) $r->n_orders . ' / ' . esc_html(self::money($r->commission)) . '</td><td>';
            self::fo('add_order', ['referral_id' => $r->id]);
            echo '<input type="number" step="0.01" min="0" name="amount" placeholder="Amount" style="width:90px" required> <select name="otype"><option value="">Auto</option><option value="first">First</option><option value="repeat">Repeat</option></select> <input type="date" name="date" value="' . esc_attr(gmdate('Y-m-d')) . '"> <button class="button button-small">Add</button></form></td><td>';
            self::fo('delete_referral', ['id' => $r->id]);
            echo '<button class="button button-small" onclick="return confirm(\'Delete this referral and its orders?\')">Delete</button></form></td></tr>';
        }
        echo '</tbody></table>';
    }

    static function tab_orders() {
        global $wpdb;
        $rows = $wpdb->get_results(
            "SELECT o.*, p.name AS pname, r.lead_email FROM " . self::t('orders') . " o
             LEFT JOIN " . self::t('partners') . " p ON p.id = o.partner_id
             LEFT JOIN " . self::t('referrals') . " r ON r.id = o.referral_id
             ORDER BY o.id DESC LIMIT 500");
        echo '<table class="widefat striped"><thead><tr><th>Order date</th><th>Partner</th><th>Lead</th><th>Amount</th><th>Type</th><th>Rate</th><th>Commission</th><th>Payout</th><th></th></tr></thead><tbody>';
        if (!$rows) echo '<tr><td colspan="9">No orders yet. Add one from the Referrals tab.</td></tr>';
        foreach ($rows as $o) {
            echo '<tr><td>' . esc_html(mysql2date('Y-m-d', $o->order_date)) . '</td><td>' . esc_html($o->pname) . '</td><td>' . esc_html($o->lead_email) . '</td>';
            echo '<td>' . esc_html(self::money($o->amount)) . '</td><td>' . esc_html(ucfirst($o->type)) . '</td><td>' . (float) $o->rate . '%</td><td><strong>' . esc_html(self::money($o->commission)) . '</strong></td><td>';
            self::fo('pay_order', ['id' => $o->id, 'paid' => $o->paid ? 0 : 1]);
            echo '<button class="button button-small' . ($o->paid ? '' : ' button-primary') . '">' . ($o->paid ? '✔ Paid (undo)' : 'Mark as paid') . '</button></form></td><td>';
            self::fo('delete_order', ['id' => $o->id]);
            echo '<button class="button button-small" onclick="return confirm(\'Delete this order?\')">Delete</button></form></td></tr>';
        }
        echo '</tbody></table>';
    }

    static function tab_settings() {
        $f = function ($k, $label, $type = 'text', $desc = '') {
            echo '<tr><th scope="row"><label>' . esc_html($label) . '</label></th><td><input class="regular-text" type="' . $type . '" step="any" name="' . esc_attr($k) . '" value="' . esc_attr(self::opt($k)) . '">';
            if ($desc) echo '<p class="description">' . esc_html($desc) . '</p>';
            echo '</td></tr>';
        };
        self::fo('save_settings');
        echo '<table class="form-table" role="presentation">';
        $f('first_rate', 'Commission: first paid order (%)', 'number');
        $f('repeat_rate', 'Commission: repeat orders (%)', 'number');
        $f('repeat_months', 'Repeat window (months)', 'number', 'Repeat orders earn commission for this many months after the first order.');
        $f('cookie_days', 'Cookie lifetime (days)', 'number');
        $f('currency', 'Currency symbol');
        $f('notify_email', 'Admin notification email', 'email');
        $f('dashboard_url', 'Referral program page URL', 'url', 'The page containing the [bg_referral_program] shortcode. Dashboard links in emails point here.');
        $f('link_base', 'Referral link landing URL', 'url', 'Partners share this URL + ?ref=CODE.');
        echo '<tr><th scope="row"><label>Auto-insert signup widget</label></th><td><select name="widget_pos">';
        foreach (['before_final' => 'On pages with the referral landing layout: before the final section (same as old plugin)', 'after_hero' => 'After the hero header', 'end' => 'At the end of the page', 'off' => 'Off (use the shortcode only)'] as $k => $l) {
            echo '<option value="' . $k . '"' . selected(self::opt('widget_pos'), $k, false) . '>' . esc_html($l) . '</option>';
        }
        echo '</select><p class="description">Only applies to pages containing the <code>rfp-page</code> layout and no shortcode.</p></td></tr>';
        foreach (['email_partner_lead' => 'Email partner when a new lead arrives', 'email_partner_conv' => 'Email partner when a lead converts', 'delete_data' => 'Delete all data when the plugin is uninstalled'] as $k => $l) {
            echo '<tr><th scope="row">' . esc_html($l) . '</th><td><label><input type="checkbox" name="' . $k . '" value="1"' . checked((int) self::opt($k), 1, false) . '> Yes</label></td></tr>';
        }
        echo '</table><p><button class="button button-primary">Save settings</button></p></form>';

        if (self::old_tables_exist()) {
            echo '<hr><h3>Import from old plugin</h3>';
            if (get_option('bgr_imported')) {
                echo '<p>✔ Old data was already imported on ' . esc_html(get_option('bgr_imported')) . '.</p>';
            } else {
                echo '<p>Found data from <em>Backlink Garden Referral Tracker</em>. This copies partners (keeping their codes and private dashboard links), visits/clicks, leads and commissions. Old data is not deleted.</p>';
                self::fo('import_old'); echo '<button class="button button-primary" onclick="return confirm(\'Import old plugin data now? Run this only once.\')">Import old data</button></form>';
            }
        }

        echo '<hr><h3>How to use</h3><ol>'
           . '<li>On the referral page the signup widget is inserted automatically. Or place <code>[bg_referral_program heading="yes"]</code> anywhere yourself.</li>'
           . '<li>Clicks on <code>calendly.com</code> links and <code>mailto:</code> links are tracked for referred visitors (the referral code is added to the email subject/body and Calendly UTM). Log those leads under Referrals &rarr; Log a lead manually.</li>'
           . '<li>Leads are captured automatically from Contact Form 7, WPForms, Gravity Forms, Elementor Forms and Fluent Forms using the visitor cookie.</li>'
           . '<li>Custom forms: <code>do_action(\'bgr_record_lead\', $name, $email);</code> or POST to <code>' . esc_html(rest_url('bgr/v1/lead')) . '</code>.</li>'
           . '<li>Test: open <code>' . esc_html(home_url('/?ref=YOURCODE')) . '</code>, then check the partner\'s visits.</li></ol>';
    }

    static function old_tables_exist() {
        global $wpdb;
        return (bool) $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($wpdb->prefix . 'bgref_referrers')));
    }

    static function import_old() {
        global $wpdb;
        $pre = $wpdb->prefix;
        $n = ['partners' => 0, 'events' => 0, 'leads' => 0];
        $map = [];

        $refs = $wpdb->get_results("SELECT * FROM {$pre}bgref_referrers ORDER BY id ASC");
        foreach ((array) $refs as $r) {
            $email = strtolower(trim((string) $r->email));
            if (!is_email($email) || self::get_by('email', $email)) $email = 'partner' . (int) $r->id . '@no-email.invalid';
            $existing = self::get_by('code', $r->code);
            if ($existing) { $map[(int) $r->id] = (int) $existing->id; continue; }
            $token = $r->token ?: bin2hex(random_bytes(16));
            $ok = $wpdb->insert(self::t('partners'), [
                'name' => $r->name, 'email' => $email, 'code' => $r->code, 'token' => $token,
                'status' => 'active', 'created_at' => $r->created,
            ]);
            if ($ok) { $map[(int) $r->id] = (int) $wpdb->insert_id; $n['partners']++; }
        }

        $ev = $wpdb->get_results("SELECT * FROM {$pre}bgref_events");
        foreach ((array) $ev as $e) {
            if (empty($map[(int) $e->referrer_id])) continue;
            $type = in_array($e->type, ['visit', 'calendly', 'email'], true) ? $e->type : 'visit';
            $wpdb->insert(self::t('visits'), ['partner_id' => $map[(int) $e->referrer_id], 'type' => $type, 'ip_hash' => '', 'landing' => $e->path, 'created_at' => $e->created]);
            $n['events']++;
        }

        $leads = $wpdb->get_results("SELECT * FROM {$pre}bgref_leads ORDER BY id ASC");
        foreach ((array) $leads as $l) {
            if (empty($map[(int) $l->referrer_id])) continue;
            $status = in_array($l->status, ['pending', 'converted', 'rewarded'], true) ? $l->status : 'pending';
            $wpdb->insert(self::t('referrals'), [
                'partner_id' => $map[(int) $l->referrer_id], 'lead_name' => $l->client, 'lead_email' => '',
                'source' => 'imported', 'status' => $status, 'notes' => $l->note,
                'created_at' => $l->created, 'converted_at' => $status === 'pending' ? null : $l->created,
            ]);
            $rid = (int) $wpdb->insert_id;
            if ($rid && $status !== 'pending' && (float) $l->order_value > 0) {
                $rate = $l->order_type === 'repeat' ? (float) self::opt('repeat_rate') : (float) self::opt('first_rate');
                $wpdb->insert(self::t('orders'), [
                    'referral_id' => $rid, 'partner_id' => $map[(int) $l->referrer_id], 'amount' => (float) $l->order_value,
                    'rate' => $rate, 'commission' => round((float) $l->order_value * $rate / 100, 2),
                    'type' => $l->order_type === 'repeat' ? 'repeat' : 'first', 'paid' => $status === 'rewarded' ? 1 : 0,
                    'order_date' => $l->created, 'created_at' => $l->created,
                ]);
            }
            $n['leads']++;
        }
        update_option('bgr_imported', current_time('mysql'));
        return sprintf('Imported %d partners, %d visits/clicks and %d leads.', $n['partners'], $n['events'], $n['leads']);
    }

    static function admin_action() {
        if (!current_user_can('manage_options')) wp_die('No permission.');
        check_admin_referer('bgr_admin');
        global $wpdb;

        $do  = sanitize_key($_POST['do'] ?? '');
        $tab = 'overview'; $msg = 'Done.';
        $id  = (int) ($_POST['id'] ?? 0);

        switch ($do) {
            case 'add_partner':
                $tab = 'partners';
                $name = sanitize_text_field(wp_unslash($_POST['name'] ?? '')); $email = sanitize_email(wp_unslash($_POST['email'] ?? ''));
                if (!$name || !is_email($email)) { $msg = 'Enter a valid name and email.'; break; }
                if (self::get_by('email', $email)) { $msg = 'That email is already a partner.'; break; }
                $p = self::create_partner($name, $email);
                if ($p) { self::send_dashboard_email($p, true); $msg = 'Partner added (code ' . $p->code . ') and welcome email sent.'; }
                break;
            case 'add_lead':
                $tab = 'referrals';
                $pid = (int) ($_POST['partner_id'] ?? 0);
                $nm  = sanitize_text_field(wp_unslash($_POST['name'] ?? ''));
                $em  = sanitize_email(wp_unslash($_POST['email'] ?? ''));
                if (!self::get_by('id', $pid) || $nm === '') { $msg = 'Choose a partner and enter a client name.'; break; }
                $wpdb->insert(self::t('referrals'), ['partner_id' => $pid, 'lead_name' => $nm, 'lead_email' => $em, 'source' => 'manual', 'status' => 'pending', 'created_at' => current_time('mysql')]);
                $msg = 'Lead added.';
                break;
            case 'import_old':
                $tab = 'settings';
                $msg = get_option('bgr_imported') ? 'Already imported.' : self::import_old();
                break;
            case 'toggle_partner':
                $tab = 'partners';
                $p = self::get_by('id', $id);
                if ($p) { $wpdb->update(self::t('partners'), ['status' => $p->status === 'active' ? 'disabled' : 'active'], ['id' => $id]); $msg = 'Partner updated.'; }
                break;
            case 'resend_partner':
                $tab = 'partners';
                $p = self::get_by('id', $id);
                if ($p) { self::send_dashboard_email($p, false); $msg = 'Dashboard link emailed.'; }
                break;
            case 'delete_partner':
                $tab = 'partners';
                $wpdb->delete(self::t('orders'), ['partner_id' => $id]);
                $wpdb->delete(self::t('referrals'), ['partner_id' => $id]);
                $wpdb->delete(self::t('visits'), ['partner_id' => $id]);
                $wpdb->delete(self::t('partners'), ['id' => $id]);
                $msg = 'Partner deleted.';
                break;
            case 'set_status':
                $tab = 'referrals';
                $st = sanitize_key($_POST['status'] ?? 'pending');
                if (in_array($st, ['pending', 'converted', 'rewarded', 'rejected'], true)) {
                    $upd = ['status' => $st];
                    if ($st === 'converted' || $st === 'rewarded') $upd['converted_at'] = current_time('mysql');
                    $wpdb->update(self::t('referrals'), $upd, ['id' => $id]);
                    $msg = 'Status updated.';
                }
                break;
            case 'add_order':
                $tab = 'referrals';
                $ok = self::add_order((int) ($_POST['referral_id'] ?? 0), (float) ($_POST['amount'] ?? 0), sanitize_text_field(wp_unslash($_POST['date'] ?? '')), sanitize_key($_POST['otype'] ?? ''));
                $msg = $ok ? 'Order added and commission calculated.' : 'Could not add order.';
                break;
            case 'pay_order':
                $tab = 'orders';
                $wpdb->update(self::t('orders'), ['paid' => empty($_POST['paid']) ? 0 : 1], ['id' => $id]);
                $rid = (int) $wpdb->get_var($wpdb->prepare("SELECT referral_id FROM " . self::t('orders') . " WHERE id = %d", $id));
                if ($rid) self::sync_referral_status($rid);
                $msg = 'Payout status updated.';
                break;
            case 'delete_order':
                $tab = 'orders';
                $rid = (int) $wpdb->get_var($wpdb->prepare("SELECT referral_id FROM " . self::t('orders') . " WHERE id = %d", $id));
                $wpdb->delete(self::t('orders'), ['id' => $id]);
                if ($rid) self::sync_referral_status($rid);
                $msg = 'Order deleted.';
                break;
            case 'delete_referral':
                $tab = 'referrals';
                $wpdb->delete(self::t('orders'), ['referral_id' => $id]);
                $wpdb->delete(self::t('referrals'), ['id' => $id]);
                $msg = 'Referral deleted.';
                break;
            case 'save_settings':
                $tab = 'settings';
                $s = [
                    'first_rate'    => max(0, (float) ($_POST['first_rate'] ?? 15)),
                    'repeat_rate'   => max(0, (float) ($_POST['repeat_rate'] ?? 5)),
                    'repeat_months' => max(1, (int) ($_POST['repeat_months'] ?? 12)),
                    'cookie_days'   => max(1, (int) ($_POST['cookie_days'] ?? 30)),
                    'currency'      => sanitize_text_field(wp_unslash($_POST['currency'] ?? '$')),
                    'notify_email'  => sanitize_email(wp_unslash($_POST['notify_email'] ?? '')),
                    'dashboard_url' => esc_url_raw(wp_unslash($_POST['dashboard_url'] ?? '')),
                    'link_base'     => esc_url_raw(wp_unslash($_POST['link_base'] ?? '')),
                    'email_partner_lead' => empty($_POST['email_partner_lead']) ? 0 : 1,
                    'email_partner_conv' => empty($_POST['email_partner_conv']) ? 0 : 1,
                    'delete_data'        => empty($_POST['delete_data']) ? 0 : 1,
                    'widget_pos'         => in_array($_POST['widget_pos'] ?? '', ['before_final', 'after_hero', 'end', 'off'], true) ? $_POST['widget_pos'] : 'before_final',
                ];
                update_option('bgr_settings', $s);
                $msg = 'Settings saved.';
                break;
        }

        wp_safe_redirect(add_query_arg(['page' => 'bgr', 'tab' => $tab, 'bgr_msg' => rawurlencode($msg)], admin_url('admin.php')));
        exit;
    }

    static function admin_export() {
        if (!current_user_can('manage_options')) wp_die('No permission.');
        check_admin_referer('bgr_export');
        global $wpdb;
        $rows = $wpdb->get_results(
            "SELECT r.id, r.created_at, p.name AS partner, p.email AS partner_email, p.code, r.lead_name, r.lead_email, r.source, r.status,
                    (SELECT COALESCE(SUM(o.commission),0) FROM " . self::t('orders') . " o WHERE o.referral_id = r.id) AS commission
             FROM " . self::t('referrals') . " r LEFT JOIN " . self::t('partners') . " p ON p.id = r.partner_id ORDER BY r.id DESC", ARRAY_A);
        nocache_headers();
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=referrals-' . gmdate('Y-m-d') . '.csv');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['ID', 'Date', 'Partner', 'Partner email', 'Code', 'Lead name', 'Lead email', 'Source', 'Status', 'Commission']);
        foreach ($rows as $r) {
            foreach ($r as $k => $v) if (is_string($v) && preg_match('/^[=+\-@]/', $v)) $r[$k] = "'" . $v; // CSV injection guard
            fputcsv($out, $r);
        }
        fclose($out);
        exit;
    }
}

BGR::init();
