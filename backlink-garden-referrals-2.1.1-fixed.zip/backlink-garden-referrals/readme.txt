=== Backlink Garden Referral Program ===
Version: 2.1.1  (replaces "Backlink Garden Referral Tracker" 1.1.0)

MIGRATE FROM THE OLD PLUGIN (do in this order)
1. Plugins > Add New > Upload Plugin > this ZIP > Activate  (leave the old plugin active for now).
2. Referrals > Settings > "Import from old plugin" > Import old data (once).
   Partners keep their codes and private dashboard links; old visits, clicks, leads and commissions are copied.
3. Deactivate the OLD plugin (Backlink Garden Referral Tracker). Do not run both.
4. Clear cache (WP Rocket / LiteSpeed / Cloudflare).
   The signup widget appears automatically on the referral page (same position as before).
   Old dashboard links (/partner-dashboard/?key=...) keep working.

TEST
- Form: submit a real email > referral link + dashboard button appear, email arrives.
- Visit https://backlinkgarden.com/?ref=YOURCODE in incognito > Link visits +1.
- Click a Calendly or mailto link on the site in that same window > click counts +1.
- Referrals tab > Log a lead manually > Add paid order (15% first / 5% repeat) > Orders & Payouts > Mark as paid.

CACHING NOTE
If "Delay JavaScript execution" is on (WP Rocket/Perfmatters), exclude: bgr.js


VERSION 2.1.1 FIXES
- Signup and lead capture work without the optional PHP mbstring extension.
- WordPress/security-plugin JSON errors now use the admin-AJAX fallback.
- Calendly/email click tracking uses fallback and keepalive requests.
- Changing referral codes refreshes decorated links and click attribution.
- Failed database order inserts no longer report successful conversions.
- Removing the final paid order resets the referral conversion state.
- Email delivery failures are reported; newly created links remain available.
- Fresh activation creates the referral page when no existing page/custom URL exists.
- Dashboard shortcode duplication and legacy dashboard cache protection fixed.

INSTALL / UPDATE ON BACKLINKGARDEN.COM
1. Back up the site/database. Upload this ZIP in WordPress > Plugins > Add New.
   If prompted, replace the existing Backlink Garden Referral Program plugin.
   Do not delete/uninstall the plugin to update it; its data-deletion setting may remove records.
2. Activate. Referrals > Settings: referral link base https://backlinkgarden.com/.
   Set Dashboard URL to the page containing [bg_referral_program] or [bg_referral_dashboard].
   Fresh installations create /backlink-referral-program/ if that page does not exist.
   If your existing page lacks the widget, add [bg_referral_program] explicitly.
3. Clear page/CDN caches. Exclude bgr.js from delayed JavaScript execution.
   Bypass page/CDN caching for URLs containing bgr_token or key (private dashboards).
4. Ensure both /wp-json/bgr/v1/* and /wp-admin/admin-ajax.php allow plugin POST requests.
5. Configure your WordPress mail/SMTP service. This plugin does not provide SMTP delivery.
6. Manual bank-transfer workflow: capture form lead or use Referrals > Log a lead.
   Once payment is received, add the paid order against that lead with amount and date.
   Keep order type Auto: default first order 15%, repeat 5% within 12 months.
   Orders & Payouts > Mark as paid records your commission payout to the partner;
   it does not initiate a bank transfer or verify receipt of payment.
7. Existing integrations: Contact Form 7, WPForms, Gravity Forms, Elementor Forms,
   Fluent Forms and bgr_record_lead hook. Use a referral_code hidden field when possible.
   Calendly/email clicks count interest; they do not automatically create confirmed leads.

RELEASE VALIDATION
Local browser DOM and PHP regression tests used mocked WordPress/database/API services.
Covered signup link display, REST JSON-403 fallback, visits, hidden fields, refreshed
Calendly/email attribution, click keepalive/fallback, Unicode without mbstring,
form leads, self-referral rejection, commission windows, payouts, failed inserts,
last-order deletion and email failure. PHP and JavaScript syntax checked.
Live WordPress/database installation and actual SMTP delivery still need site verification.
