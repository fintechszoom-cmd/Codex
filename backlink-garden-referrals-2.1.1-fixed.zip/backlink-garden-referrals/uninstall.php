<?php
if (!defined('WP_UNINSTALL_PLUGIN')) exit;
$s = get_option('bgr_settings', []);
if (!empty($s['delete_data'])) {
    global $wpdb;
    foreach (['orders', 'referrals', 'visits', 'partners'] as $t) {
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}bgr_{$t}");
    }
    delete_option('bgr_settings');
    delete_option('bgr_db_ver');
}
