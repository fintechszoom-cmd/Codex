(function () {
  'use strict';
  var C = window.BGR || {};
  var GENERIC = 'Something went wrong. Please try again.';

  /* ---------- cookies ---------- */
  function getCookie(n) {
    var m = document.cookie.match(new RegExp('(?:^|; )' + n + '=([^;]*)'));
    return m ? decodeURIComponent(m[1]) : null;
  }
  function setCookie(n, v, d) {
    var e = new Date(Date.now() + d * 864e5).toUTCString();
    document.cookie = n + '=' + encodeURIComponent(v) + '; expires=' + e + '; path=/; SameSite=Lax' + (location.protocol === 'https:' ? '; Secure' : '');
  }
  function delCookie(n) {
    document.cookie = n + '=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/';
  }

  /* ---------- API: REST first, admin-ajax fallback ---------- */
  function viaAjax(route, data, keepalive) {
    var fd = new URLSearchParams();
    fd.append('action', 'bgr_api');
    fd.append('route', route);
    Object.keys(data).forEach(function (k) { fd.append(k, data[k]); });
    return fetch(C.ajax, { method: 'POST', body: fd, credentials: 'same-origin', keepalive: !!keepalive })
      .then(function (r) { return r.json(); });
  }
  function api(route, data, keepalive) {
    return fetch(C.rest + route, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
      keepalive: !!keepalive,
      credentials: 'same-origin'
    }).then(function (r) {
      var ct = r.headers.get('content-type') || '';
      if (ct.indexOf('json') < 0 || r.status === 404 || r.status === 401) throw new Error('rest-unavailable');
      return r.json().then(function (j) {
        // WordPress/security-plugin errors are not responses from our handler.
        if (!j || typeof j.ok !== 'boolean') throw new Error('rest-unavailable');
        return j;
      });
    }).catch(function () {
      return viaAjax(route, data, keepalive);
    });
  }

  /* ---------- tracking + hidden fields ---------- */
  function fillFields() {
    var v = getCookie(C.cookie);
    if (!v) return;
    var els = document.querySelectorAll('input[name*="referral_code"], input#referral_code, input[name="referral-code"]');
    for (var i = 0; i < els.length; i++) { if (els[i].value !== v) els[i].value = v; }
  }

  function track() {
    var ref = null;
    try { ref = new URLSearchParams(location.search).get('ref'); } catch (e) {}
    if (ref) {
      ref = ref.replace(/[^A-Za-z0-9_-]/g, '').slice(0, 80);
      if (ref) {
        setCookie(C.cookie, ref, C.days || 30);
        var key = 'bgr_v_' + ref, seen = false;
        try { seen = sessionStorage.getItem(key); } catch (e) {}
        if (!seen) {
          api('visit', { code: ref, landing: location.pathname }).then(function (j) {
            if (j && j.valid === false) { delCookie(C.cookie); }
            else if (j && j.ok === true && j.valid === true) { try { sessionStorage.setItem(key, '1'); } catch (e) {} }
          }).catch(function () {});
        }
      }
    }
    fillFields();
    decorate();
  }

  /* ---------- Calendly / mailto click tracking ---------- */
  function cleanCode(v) { v = String(v || ''); return /^[A-Za-z0-9][A-Za-z0-9_-]{2,79}$/.test(v) ? v : ''; }
  function decorate() {
    var code = cleanCode(getCookie(C.cookie));
    if (!code) return;
    var links = document.querySelectorAll('a[href]');
    for (var i = 0; i < links.length; i++) {
      (function (a) {
        var original = a.getAttribute('data-bgr-original-href');
        var h = original !== null ? original : (a.getAttribute('href') || ''), type = '';
        if (original === null) a.setAttribute('data-bgr-original-href', h);
        if (/^mailto:/i.test(h)) {
          var sep = h.indexOf('?') > -1 ? '&' : '?';
          if (!/[?&]subject=/i.test(h)) { h += sep + 'subject=' + encodeURIComponent('Enquiry (Referral: ' + code + ')'); sep = '&'; }
          if (!/[?&]body=/i.test(h)) { h += sep + 'body=' + encodeURIComponent('Hi,\n\n\n\n---\nReferral code: ' + code + ' (please keep this line)'); }
          a.setAttribute('href', h);
          type = 'email';
        } else if (/calendly\.com/i.test(h)) {
          try {
            var u = new URL(h, location.href);
            if (/(^|\.)calendly\.com$/i.test(u.hostname)) {
              if (!u.searchParams.get('utm_source')) u.searchParams.set('utm_source', 'referral');
              if (!u.searchParams.get('utm_medium')) u.searchParams.set('utm_medium', 'partner');
              if (!u.searchParams.get('utm_campaign')) u.searchParams.set('utm_campaign', code);
              a.setAttribute('href', u.toString());
              type = 'calendly';
            }
          } catch (e) {}
        }
        if (type) {
          if (!a.getAttribute('data-bgref')) {
            a.setAttribute('data-bgref', '1');
            a.addEventListener('click', function () {
              var current = cleanCode(getCookie(C.cookie));
              if (!current) return;
              api('visit', { code: current, type: type, landing: location.pathname }, true).catch(function () {});
            });
          }
        }
      })(links[i]);
    }
  }

  /* ---------- returning partner hint ---------- */
  function welcomeBack() {
    var app = document.querySelector('[data-bgr-app]');
    if (!app || !C.dash) return;
    var tok = null;
    try { tok = localStorage.getItem('bgr_token'); } catch (e) {}
    if (!tok || !/^[a-f0-9]{16,64}$/.test(tok)) return;
    var box = app.querySelector('.bgr-msg');
    if (!box || !box.hidden) return; // don't overwrite an error
    var a = el('a', null, 'Open my dashboard');
    a.href = C.dash + (C.dash.indexOf('?') > -1 ? '&' : '?') + 'bgr_token=' + tok;
    a.style.fontWeight = '700'; a.style.textDecoration = 'underline';
    box.className = 'bgr-msg bgr-info';
    box.textContent = 'Welcome back! ';
    box.appendChild(a);
    box.hidden = false;
  }

  var t;
  function watch() {
    if (!window.MutationObserver) return;
    new MutationObserver(function () { clearTimeout(t); t = setTimeout(function () { fillFields(); decorate(); }, 150); })
      .observe(document.body, { childList: true, subtree: true });
  }

  /* ---------- helpers ---------- */
  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }
  function copy(text, btn) {
    function done() { var o = btn.textContent; btn.textContent = 'Copied!'; setTimeout(function () { btn.textContent = o; }, 1500); }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(done, fallback);
    } else fallback();
    function fallback() {
      var ta = document.createElement('textarea');
      ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
      document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); done(); } catch (e) {}
      document.body.removeChild(ta);
    }
  }
  function showError(app, msg) {
    var box = app.querySelector('.bgr-msg');
    if (!box) return;
    box.className = 'bgr-msg bgr-error';
    box.textContent = msg;
    box.hidden = false;
  }
  function showInfo(app, msg) {
    var box = app.querySelector('.bgr-msg');
    if (!box) return;
    box.className = 'bgr-msg bgr-info';
    box.textContent = msg;
    box.hidden = false;
  }
  function clearMsg(app) {
    var box = app.querySelector('.bgr-msg');
    if (box) { box.hidden = true; box.textContent = ''; }
  }
  function panel(app, name) {
    var ps = app.querySelectorAll('[data-panel]');
    for (var i = 0; i < ps.length; i++) ps[i].hidden = ps[i].getAttribute('data-panel') !== name;
  }

  /* ---------- signup UI ---------- */
  function renderSuccess(app, j) {
    var box = app.querySelector('[data-panel="success"]');
    box.innerHTML = '';
    try { var m = /bgr_token=([a-f0-9]+)/.exec(j.dashboard || ''); if (m) localStorage.setItem('bgr_token', m[1]); } catch (e) {}
    box.appendChild(el('h3', 'bgr-h', "You're in! 🎉"));
    box.appendChild(el('p', 'bgr-sub', 'Your referral code: ' + j.code));

    box.appendChild(el('label', 'bgr-lbl', 'Your referral link'));
    var row = el('div', 'bgr-copy');
    var input = el('input'); input.type = 'text'; input.readOnly = true; input.value = j.link;
    var btn = el('button', 'bgr-btn', 'Copy'); btn.type = 'button';
    btn.addEventListener('click', function () { copy(j.link, btn); });
    row.appendChild(input); row.appendChild(btn);
    box.appendChild(row);

    var a = el('a', 'bgr-btn bgr-btn-link', 'Open my live dashboard');
    a.href = j.dashboard;
    box.appendChild(a);
    box.appendChild(el('p', 'bgr-terms', j.email_sent === false ? "Your account is ready, but email delivery failed. Save your referral link and private dashboard URL now, and contact the site administrator." : "We've also emailed you your link and private dashboard URL. Please check your spam folder if you don't see it."));
    panel(app, 'success');
  }

  function busy(form, on, label) {
    var b = form.querySelector('button[type="submit"]');
    if (!b) return;
    if (on) { b.dataset.l = b.textContent; b.textContent = label || 'Please wait…'; b.disabled = true; }
    else { b.textContent = b.dataset.l || b.textContent; b.disabled = false; }
  }

  function onSubmit(e) {
    var form = e.target.closest('form[data-bgr]');
    if (!form) return;
    e.preventDefault();
    var app = form.closest('[data-bgr-app]');
    var kind = form.getAttribute('data-bgr');
    clearMsg(app);

    var data = {};
    new FormData(form).forEach(function (v, k) { data[k] = v; });

    if (kind === 'signup') {
      if (!data.name || String(data.name).trim().length < 2) return showError(app, 'Please enter your name.');
    }
    if (!data.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) return showError(app, 'Please enter a valid email address.');

    busy(form, true);
    api(kind, data).then(function (j) {
      busy(form, false);
      if (!j || j.ok === false) return showError(app, (j && j.message) || GENERIC);
      if (kind === 'signup' && !j.existing) return renderSuccess(app, j);
      showInfo(app, j.message || 'Done.');
      panel(app, 'signup');
      form.reset();
    }).catch(function (err) {
      if (window.console) console.error('[BGR]', err);
      busy(form, false);
      showError(app, GENERIC);
    });
  }

  function onClick(e) {
    var tg = e.target.closest('[data-toggle]');
    if (tg) {
      e.preventDefault();
      var app = tg.closest('[data-bgr-app]');
      clearMsg(app);
      panel(app, tg.getAttribute('data-toggle'));
      return;
    }
    var cp = e.target.closest('[data-copy]');
    if (cp) { e.preventDefault(); copy(cp.getAttribute('data-copy'), cp); }
  }

  /* ---------- live dashboard ---------- */
  function refreshDash(root) {
    api('stats', { token: root.getAttribute('data-token') }).then(function (j) {
      if (!j || j.ok === false) return;
      var s = j.stats || {};
      Object.keys(s).forEach(function (k) {
        var n = root.querySelector('[data-stat="' + k + '"]');
        if (n) n.textContent = s[k];
      });
      var body = root.querySelector('[data-rows]');
      if (!body) return;
      body.innerHTML = '';
      if (!j.rows || !j.rows.length) {
        var tr = el('tr', 'bgr-empty'); var td = el('td', null, 'No referrals yet. Share your link to get started.');
        td.colSpan = 4; tr.appendChild(td); body.appendChild(tr); return;
      }
      j.rows.forEach(function (r) {
        var tr = document.createElement('tr');
        tr.appendChild(el('td', null, r.date));
        tr.appendChild(el('td', null, r.lead));
        var st = document.createElement('td');
        st.appendChild(el('span', 'bgr-badge bgr-' + String(r.status).replace(/[^a-z]/g, ''), r.label));
        tr.appendChild(st);
        tr.appendChild(el('td', null, r.commission));
        body.appendChild(tr);
      });
    }).catch(function () {});
  }

  function initDash() {
    var roots = document.querySelectorAll('[data-bgr-dash]');
    Array.prototype.forEach.call(roots, function (root) {
      setInterval(function () { if (!document.hidden) refreshDash(root); }, 30000);
    });
  }

  /* ---------- boot ---------- */
  function boot() {
    track();
    welcomeBack();
    watch();
    document.addEventListener('submit', onSubmit);
    document.addEventListener('click', onClick);
    initDash();
  }
  window.addEventListener('load', fillFields);
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
